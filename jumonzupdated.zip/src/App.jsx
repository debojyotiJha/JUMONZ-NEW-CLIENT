import React from 'react'
import AppRouters from '../AppRouters'
import './main.css'

function App() {
  return (
    <AppRouters/>
  )
}

export default App