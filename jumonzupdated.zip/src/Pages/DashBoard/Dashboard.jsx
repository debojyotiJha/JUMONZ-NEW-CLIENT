import React from 'react'

import DashboardComp from '../../Components/Dashboard/DashboardComp';


function Dashboard() {
  return (
    <>
        <DashboardComp/>
    </>
  )
}

export default Dashboard