import React from 'react'
import AddPostComp from '../../Components/AddPost/AddPostComp'
function AddPost() {
  return (
    <>
    <AddPostComp/>
    </>
  )
}

export default AddPost