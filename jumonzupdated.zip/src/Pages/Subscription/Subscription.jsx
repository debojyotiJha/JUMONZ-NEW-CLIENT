import React from 'react'
import SubscriptionComp from '../../Components/Subscription/SubscriptionComp.jsx'

function Subscription() {
  return (
    <>
    <SubscriptionComp/>
    
    </>
  )
}

export default Subscription