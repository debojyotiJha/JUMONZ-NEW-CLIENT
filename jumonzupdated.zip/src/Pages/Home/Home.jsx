import React from 'react'
import HomeComp from '../../Components/Home/HomeComp'
function AddPost() {
  return (
    <>
    <HomeComp/>
    </>
  )
}

export default AddPost